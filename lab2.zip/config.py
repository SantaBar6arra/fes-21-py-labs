class Config:   
    FIELD_HEIGHT = 20   
    FIELD_WIDTH = 20   
    COLONY_SIZE = 5    
    DIMENSION = 2      
    EMPLOYED_AGENTS = 3
    SOURCES = 10
    MAX_FIELD_CAPACITY = 100
